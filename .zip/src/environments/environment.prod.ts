export const environment = {
  production: true,
  apiUrl: 'http://localhost:51987/api/',
  fromEmailId: 'ganga123081@gmail.com'
};

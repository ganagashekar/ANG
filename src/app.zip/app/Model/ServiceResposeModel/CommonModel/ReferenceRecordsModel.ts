export class ReferenceRecords {
    id: bigint;
    name: string;
    referenceRecordTyepId: bigint;
}

export class ParameterFilter {
  StackId: bigint;
  SiteId: bigint;
  ParamId: bigint;
}

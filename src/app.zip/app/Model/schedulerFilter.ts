

export class SchedulerFilter  {
    InstanceId: number;
    TaskId: number;
    FrequencyType: number;
    IsActive: boolean;
}

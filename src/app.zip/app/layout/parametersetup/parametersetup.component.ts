import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, FormControl, FormArray, ValidatorFn } from '@angular/forms';
import { SchedulerFilter } from 'src/app/Model/schedulerFilter';
@Component({
  selector: 'app-parametersetup',
  templateUrl: './parametersetup.component.html',
  styleUrls: ['./parametersetup.component.scss']
})
export class ParametersetupComponent implements OnInit {
  schedulerFilter: SchedulerFilter;

  constructor() {

    // this.schedulerFilter = new SchedulerFilter();
    // this.schedulerFilter.IsActive = true;
    // this.schedulerFilter.InstanceId = 0;
    // this.schedulerFilter.TaskId = 0;
    // this.schedulerFilter.FrequencyType = 0;

  }

  ngOnInit() {

    this.schedulerFilter = new SchedulerFilter();
    this.schedulerFilter.IsActive = true;
    this.schedulerFilter.InstanceId = 0;
    this.schedulerFilter.TaskId = 0;
    this.schedulerFilter.FrequencyType = 0;
  }

}

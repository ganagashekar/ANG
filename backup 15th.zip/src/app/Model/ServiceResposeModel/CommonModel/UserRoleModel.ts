export class UserRole {
  role_id: bigint;
  name: string;
  description: string;
}

import { DateTime } from 'luxon';

export class ControllerModel {
    macId: string;
    siteId: bigint;
    OsType: string;
    cpcbUrl: string;
    spcburl: string;
    LicenseKey: string;
    updtts: DateTime;
    // length: number;
    // creatts: DateTime;
    // updtts: DateTime;









}

import { DateTime } from 'luxon';

export class ErrorCodeModel {
  errorcode: string;
  errordesc: string;
  updt_ts: DateTime;
}






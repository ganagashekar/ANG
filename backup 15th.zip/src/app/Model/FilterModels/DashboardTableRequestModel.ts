export class DashboardTableRequestModel {
  fromDate: Date;
toDate: Date;
dataId: number;
siteId: number;
}

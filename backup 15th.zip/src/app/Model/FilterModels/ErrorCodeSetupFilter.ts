export class ErrorCodeSetupFilter {
  error_code: string;
  error_desc: string;
}

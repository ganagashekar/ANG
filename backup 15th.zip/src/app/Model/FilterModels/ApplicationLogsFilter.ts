export class ApplicationLogsFilter {
  LogId: number;
  ConfgId: number;
}

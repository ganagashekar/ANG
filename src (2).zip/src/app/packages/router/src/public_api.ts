export { LoadingBarRouterModule } from './router.module';

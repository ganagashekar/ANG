import { DateTime } from 'luxon';

export class ControllerModel {
    macId: string;
    siteId: bigint;
    OsType: string;
    cpcb_url: string;
    spcb_url: string;
    licence_key: string;
    updtts: DateTime;
    // length: number;
    // creatts: DateTime;
    // updtts: DateTime;









}

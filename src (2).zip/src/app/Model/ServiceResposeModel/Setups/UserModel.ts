import { DateTime } from 'luxon';

export class UserModel {
    userId: bigint;
    userPass: string;
    isEnabled: number;
    userName: string;
    siteId: bigint;
    creatts: DateTime;
    updtts: DateTime;
     // length: number;
     // creatts: DateTime;
     // updtts: DateTime;









}

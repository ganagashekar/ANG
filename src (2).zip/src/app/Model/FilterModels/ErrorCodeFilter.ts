export class ErrorCodeFilter {
  error_code: string;
  error_desc: string;
}

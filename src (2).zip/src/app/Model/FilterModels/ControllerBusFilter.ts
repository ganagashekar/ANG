export class ControllerBusFilter {
  BusId: number;
  MacId: string;
  Protocal: string;
}

export class ParameterFilter {
  StackId: number;
  SiteId: number;
  ParamId: number;
}

export class ReportRequestModel {
  StackId: number;
  SiteId: number;
  ParamId: number;
  FromDate: string;
  ToDate: string;
  TimePeriod: number;

}

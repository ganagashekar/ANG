export class ExceedenceReportModel {

    stackName: string;
    paramName: string;
    paramUnits: string;
    recordedDate: Date;
    paramValue: number;
    description: string ;

}

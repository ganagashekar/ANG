export class DashboardQuickDataModel {
  stackName: string;
  paramName: string;
  paramUnits: string;
  recordedDate: Date;
  paramValue: number;
  threShholdValue: number;
  data_id: number;
  configId: number;
  isGroupby: boolean;
  status: boolean;
}

export class DashboardQuickCounts {
  stackCount: number;
  paramCount: number;
  exceedenceCount: number;
  alertCount: number;

}

import { DateTime } from 'luxon';

export class ControllerModel {
    macId: string;
    siteId: bigint;
    osType: string;
    cpcbUrl: string;
    spcburl: string;
    licenseKey: string;
    updtts: DateTime;

    // length: number;
    // creatts: DateTime;
    // updtts: DateTime;









}

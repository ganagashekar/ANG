import { DateTime } from 'luxon';

export class ErrorCodeSetupModel {
  errorcode: string;
  errordesc: string;
  updt_ts: DateTime;
}






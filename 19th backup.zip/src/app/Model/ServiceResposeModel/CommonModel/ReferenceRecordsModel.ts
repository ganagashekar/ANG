export class ReferenceRecords {
    id: number;
    name: string;
    referenceRecordTyepId: number;
}

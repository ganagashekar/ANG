export class SiteSetupFilter {
  SiteId: number;
  SiteName: string;
}

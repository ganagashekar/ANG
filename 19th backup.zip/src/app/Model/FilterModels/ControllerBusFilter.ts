export class ControllerBusFilter {
  BusId: number;
  MacId: string;
  SiteId: number;
  Protocal: string;
}

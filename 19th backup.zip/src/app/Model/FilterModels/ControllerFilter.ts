export class ControllerFilter {
  MacId: String;
  SiteId: number;
}

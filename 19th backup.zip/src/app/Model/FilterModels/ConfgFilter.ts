export class ConfgFilter {
  SiteId:  string;
  ConfgId: number;
  BusId: number;
  VendorId: string;
}

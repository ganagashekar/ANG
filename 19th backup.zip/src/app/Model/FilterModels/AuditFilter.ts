export class AuditFilter {
  AuditId: number;
  SiteId:  string;
  ConfgId: number;
}

export class UserinfoFilter {
  UserId: number;
  UserName: string;
  SiteId: number;
  UserPass: string;
  IsEnabled: number;
}

export const environment = {
  production: true,
  apiUrl: 'http://localhost:44390/api/',
  fromEmailId: 'ganga123081@gmail.com'
};
